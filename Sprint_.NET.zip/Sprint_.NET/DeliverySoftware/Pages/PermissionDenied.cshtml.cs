using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DeliverySoftware.Pages
{
    public class PermissionDeniedModel : PageModel
    {
        public void OnGet ()
        {
        }
    }
}
