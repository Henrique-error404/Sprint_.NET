﻿namespace DeliverySoftware.Business.Delivery
{
    public enum DeliveryStatus
    {
        Unknown = 0,
        Pending = 1,
        Started = 2,
        Completed = 3
    }
}
