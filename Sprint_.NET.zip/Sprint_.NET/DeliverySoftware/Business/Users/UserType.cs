﻿namespace DeliverySoftware.Business.Users
{
    public enum UserType
    {
        Unconfigured = 0,
        Customer = 1,
        Driver = 2,
        Employee = 3
    }
}
