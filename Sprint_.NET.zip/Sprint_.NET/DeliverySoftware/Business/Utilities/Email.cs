﻿namespace DeliverySoftware.Business.Utilities
{
    public class Email
    {
        public string Body { get; set; }
        public string Recipient { get; set; }
        public string Subject { get; set; }
    }
}
